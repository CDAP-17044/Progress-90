#! /bin/bash
scp /C/CSVfiles/DataSetE.csv ubuntu@184.73.132.39:.