$Time = Get-Content 'C:\InputFiles\TIME.txt'
$Current = Get-Content 'C:\InputFiles\CUR.txt'
$volt = Get-Content 'C:\InputFiles\VOLT.txt'

$excel = New-Object -ComObject excel.application
$excel.visible = $False
$workbook = $excel.Workbooks.Add()
$diskSpacewksht= $workbook.Worksheets.Item(1)

$row = 1
$col1 = 1
$col2 = 1

	foreach ($timeVal in $Time){

		$diskSpacewksht.Cells.Item($row,1) = $timeVal
		$row++

	}

	foreach ($currentVal in $Current){

		$diskSpacewksht.Cells.Item($col1,2) = $currentVal
		$col1++

	}

	foreach ($voltVal in $volt){

		$diskSpacewksht.Cells.Item($col2,3) = $voltVal
		$col2++

	}

$excel.DisplayAlerts = 'False'
$ext=".xlsx"
$path="C:\CSVfiles\DataSetE$ext"
$workbook.SaveAs($path) 
$workbook.Close
$excel.DisplayAlerts = 'False'
$excel.Quit()

$ErrorActionPreference = 'Stop'

Function Convert-CsvInBatch
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true)][String]$Folder
	)
	$ExcelFiles = Get-ChildItem -Path $Folder -Filter *.xlsx -Recurse

	$excelApp = New-Object -ComObject Excel.Application
	$excelApp.DisplayAlerts = $false

	$ExcelFiles | ForEach-Object {
		$workbook = $excelApp.Workbooks.Open($_.FullName)
		$csvFilePath = $_.FullName -replace "\.xlsx$", ".csv"
		$workbook.SaveAs($csvFilePath, [Microsoft.Office.Interop.Excel.XlFileFormat]::xlCSV)
		$workbook.Close()
	}

	# Release Excel Com Object resource
	$excelApp.Workbooks.Close()
	$excelApp.Visible = $true
	Start-Sleep 5
	$excelApp.Quit()
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excelApp) | Out-Null
}

#
# 0. Prepare the folder path which contains all excel files
$FolderPath = "C:\CSVfiles\DataSetE.xlsx"

Convert-CsvInBatch -Folder $FolderPath